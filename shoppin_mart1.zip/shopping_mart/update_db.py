import sqlite3

db = sqlite3.connect("database.db")

db.execute("""
CREATE TABLE cart(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER,
    quantity INTEGER
)
""")

db.commit()
db.close()

print("✅ Cart table created")
