import sqlite3

db = sqlite3.connect("database.db")
cur = db.cursor()

cur.execute("DROP TABLE IF EXISTS orders")

cur.execute("""
CREATE TABLE orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_name TEXT,
    price REAL,
    quantity INTEGER,
    image TEXT,
    customer_name TEXT,
    phone TEXT,
    address TEXT,
    payment_method TEXT,
    status TEXT
)
""")

db.commit()
db.close()

print("✅ Orders table reset & updated successfully")
