import sqlite3
from werkzeug.security import generate_password_hash

conn = sqlite3.connect("database.db")
cur = conn.cursor()

# ---------------- USERS TABLE ----------------
cur.execute("""
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    is_admin INTEGER
)
""")

# ---------------- PRODUCTS TABLE ----------------
cur.execute("""
CREATE TABLE IF NOT EXISTS products(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    category TEXT,
    price REAL,
    description TEXT,
    image TEXT
)
""")

# ---------------- CART TABLE ----------------
cur.execute("""
CREATE TABLE IF NOT EXISTS cart(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER,
    quantity INTEGER
)
""")

# ---------------- ORDERS TABLE (IMPORTANT) ----------------
cur.execute("""
CREATE TABLE IF NOT EXISTS orders(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_name TEXT,
    price REAL,
    quantity INTEGER,
    customer_name TEXT,
    phone TEXT,
    address TEXT,
    status TEXT
)
""")

# ---------------- ONLY ONE ADMIN ----------------
admin_username = "ankushbarud01@gmail.com"
admin_password = generate_password_hash("ankush9049188017")

cur.execute("SELECT * FROM users WHERE username=?", (admin_username,))
if not cur.fetchone():
    cur.execute(
        "INSERT INTO users (username, password, is_admin) VALUES (?, ?, ?)",
        (admin_username, admin_password, 1)
    )

conn.commit()
conn.close()

print("✅ Database ready (Admin + Products + Cart + Orders)")


