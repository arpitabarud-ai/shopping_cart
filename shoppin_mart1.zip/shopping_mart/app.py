from flask import Flask, render_template, request, redirect, session
import sqlite3
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = "supersecretkey123"

# ---------- IMAGE UPLOAD ----------
UPLOAD_FOLDER = "static/uploads"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ---------- ADMIN ----------
ADMIN_USERNAME = "ankushbarud01@gmail.com"
ADMIN_PASSWORD = "ankush9049188017"

# ---------- DATABASE ----------
def get_db():
    conn = sqlite3.connect("database.db")
    conn.row_factory = sqlite3.Row
    return conn


# =========================================================
# HOME
# =========================================================
@app.route("/")
def home():

    category = request.args.get("category")
    db = get_db()

    if category and category != "All":
        products = db.execute(
            "SELECT * FROM products WHERE category=?",
            (category,)
        ).fetchall()
    else:
        products = db.execute("SELECT * FROM products").fetchall()

    db.close()

    return render_template(
        "products.html",
        products=products,
        selected_category=category
    )


# =========================================================
# ADD TO CART
# =========================================================
# =========================================================
# ADD TO CART
# =========================================================
@app.route("/add_to_cart", methods=["POST"])
def add_to_cart():

    product_id = request.form.get("product_id")

    if not product_id:
        return redirect("/")

    try:
        product_id = int(product_id)
    except ValueError:
        return redirect("/")

    db = get_db()

    product = db.execute(
        "SELECT * FROM products WHERE id=?",
        (product_id,)
    ).fetchone()

    db.close()

    if not product:
        return redirect("/")

    cart = session.get("cart", [])

    found = False

    # product already exists
    for item in cart:

        if item["id"] == product["id"]:

            item["quantity"] += 1
            found = True
            break

    # new product
    if not found:

        cart.append({
            "id": product["id"],
            "name": product["name"],
            "price": float(product["price"]),
            "image": product["image"],
            "quantity": 1
        })

    session["cart"] = cart
    session.modified = True

    return redirect("/cart")


# =========================================================
# CART PAGE
# =========================================================
@app.route("/cart")
def cart():

    cart = session.get("cart", [])

    total = sum(
        float(item["price"]) * item["quantity"]
        for item in cart
    )

    return render_template(
        "cart.html",
        cart=cart,
        total=total
    )


# =========================================================
# BUY NOW CHECKOUT
# =========================================================
@app.route("/checkout/<int:product_id>")
def buy_now_checkout(product_id):

    db = get_db()

    product = db.execute(
        "SELECT * FROM products WHERE id=?",
        (product_id,)
    ).fetchone()

    db.close()

    if not product:
        return redirect("/")

    return render_template(
        "checkout.html",
        product_name=product["name"],
        price=product["price"],
        quantity=1,
        image=product["image"],
        cart=None
    )


# =========================================================
# CART CHECKOUT
# =========================================================
@app.route("/checkout", methods=["GET", "POST"])
def cart_checkout():

    cart = session.get("cart", [])

    if not cart:
        return redirect("/")

    total = sum(
        float(item["price"]) * item["quantity"]
        for item in cart
    )

    return render_template(
        "checkout.html",
        cart=cart,
        total=total
    )


# =========================================================
# PLACE ORDER
# =========================================================
@app.route("/place_order", methods=["POST"])
def place_order():

    name = request.form["name"]
    phone = request.form["phone"]
    address = request.form["address"]

    db = get_db()

    # BUY NOW
    if request.form.get("product_name"):

        db.execute("""
            INSERT INTO orders
            (
                product_name,
                price,
                quantity,
                image,
                customer_name,
                phone,
                address,
                payment_method,
                status
            )
            VALUES (?,?,?,?,?,?,?,?,?)
        """, (
            request.form["product_name"],
            request.form["price"],
            request.form["quantity"],
            request.form.get("image"),
            name,
            phone,
            address,
            "Cash on Delivery",
            "Confirmed"
        ))

    # CART ORDER
    else:

        cart = session.get("cart", [])

        for item in cart:

            db.execute("""
                INSERT INTO orders
                (
                    product_name,
                    price,
                    quantity,
                    image,
                    customer_name,
                    phone,
                    address,
                    payment_method,
                    status
                )
                VALUES (?,?,?,?,?,?,?,?,?)
            """, (
                item["name"],
                item["price"],
                item["quantity"],
                item["image"],
                name,
                phone,
                address,
                "Cash on Delivery",
                "Confirmed"
            ))

        session.pop("cart", None)

    db.commit()
    db.close()

    return render_template("order_success.html")


# =========================================================
# CUSTOMER ORDER HISTORY
# =========================================================
@app.route("/my_orders", methods=["GET", "POST"])
def my_orders():

    if request.method == "POST":

        phone = request.form["phone"]

        db = get_db()

        orders = db.execute(
            "SELECT * FROM orders WHERE phone=? ORDER BY id DESC",
            (phone,)
        ).fetchall()

        db.close()

        return render_template(
            "orders.html",
            orders=orders,
            phone=phone
        )

    return render_template("orders.html", orders=None)


# =========================================================
# ADMIN LOGIN
# =========================================================
@app.route("/admin", methods=["GET", "POST"])
def admin_login():

    error = None

    if request.method == "POST":

        if (
            request.form["username"] == ADMIN_USERNAME and
            request.form["password"] == ADMIN_PASSWORD
        ):

            session["admin"] = True
            return redirect("/dashboard")

        else:
            error = "Invalid credentials"

    return render_template(
        "admin_login.html",
        error=error
    )


# =========================================================
# ADMIN DASHBOARD
# =========================================================
@app.route("/dashboard")
def dashboard():

    if not session.get("admin"):
        return redirect("/admin")

    db = get_db()

    products = db.execute(
        "SELECT * FROM products"
    ).fetchall()

    db.close()

    return render_template(
        "admin_dashboard.html",
        products=products
    )


# =========================================================
# ADD PRODUCT
# =========================================================
@app.route("/add", methods=["GET", "POST"])
def add_product():

    if not session.get("admin"):
        return redirect("/admin")

    if request.method == "POST":

        name = request.form["name"]
        category = request.form["category"]
        price = request.form["price"]
        description = request.form["description"]

        image_url = request.form.get("image_url")
        image_file = request.files.get("image_file")

        if image_file and image_file.filename != "":

            filename = secure_filename(
                image_file.filename
            )

            image_file.save(
                os.path.join(
                    app.config["UPLOAD_FOLDER"],
                    filename
                )
            )

            image = "/static/uploads/" + filename

        else:
            image = image_url

        db = get_db()

        db.execute("""
            INSERT INTO products
            (
                name,
                category,
                price,
                description,
                image
            )
            VALUES (?,?,?,?,?)
        """, (
            name,
            category,
            price,
            description,
            image
        ))

        db.commit()
        db.close()

        return redirect("/dashboard")

    return render_template("add_product.html")


# =========================================================
# EDIT PRODUCT
# =========================================================
@app.route("/edit/<int:id>", methods=["GET", "POST"])
def edit_product(id):

    if not session.get("admin"):
        return redirect("/admin")

    db = get_db()

    if request.method == "POST":

        name = request.form["name"]
        category = request.form["category"]
        price = request.form["price"]
        description = request.form["description"]

        db.execute("""
            UPDATE products
            SET
                name=?,
                category=?,
                price=?,
                description=?
            WHERE id=?
        """, (
            name,
            category,
            price,
            description,
            id
        ))

        db.commit()
        db.close()

        return redirect("/dashboard")

    product = db.execute(
        "SELECT * FROM products WHERE id=?",
        (id,)
    ).fetchone()

    db.close()

    return render_template(
        "edit_product.html",
        product=product
    )


# =========================================================
# ADMIN ORDERS
# =========================================================
@app.route("/admin/orders")
def admin_orders():

    if not session.get("admin"):
        return redirect("/admin")

    db = get_db()

    orders = db.execute(
        "SELECT * FROM orders ORDER BY id DESC"
    ).fetchall()

    db.close()

    return render_template(
        "admin_orders.html",
        orders=orders
    )


# =========================================================
# UPDATE ORDER STATUS
# =========================================================
@app.route("/update_status/<int:oid>/<status>")
def update_status(oid, status):

    if not session.get("admin"):
        return redirect("/admin")

    db = get_db()

    db.execute(
        "UPDATE orders SET status=? WHERE id=?",
        (status, oid)
    )

    db.commit()
    db.close()

    return redirect("/admin/orders")


# =========================================================
# LOGOUT
# =========================================================
@app.route("/logout")
def logout():

    session.clear()

    return redirect("/admin")


# =========================================================
# RUN
# =========================================================
if __name__ == "__main__":
    app.run(debug=True)